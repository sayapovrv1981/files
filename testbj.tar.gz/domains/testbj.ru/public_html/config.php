<?php
// для подключения к бд
define('DB_USER', 'sayapovrv_root');
define('DB_PASS', '28011981');
define('DB_HOST', 'localhost');
define('DB_NAME', 'sayapovrv_testbj');
define('ROWS_NUMBER_ONPAGE', 3);
define('PAGE_LINK', 3);
