<?php

class Model
{
	// метод выборки данных
	public function get_data()
	{
		// todo
	}
	public function get_pagination()
	{
		// todo
	}
}
