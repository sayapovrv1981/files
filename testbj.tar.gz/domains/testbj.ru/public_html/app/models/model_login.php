<?php
class Model_Login extends Model
{
  public function get_data()
  {
    if(isset($_POST['login']) && isset($_POST['password']))
    {
      $login = $_POST['login'];
      $password = md5($_POST['password']);
      //запрашиваем пароль админа из БД
      $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

      if (mysqli_connect_errno())
      {
      echo "Ошибка подключения к серверу MySQL. Код ошибки:".mysqli_connect_error();

      return ([]);
      }

      $pass = mysqli_fetch_array($mysqli->query('SELECT pass FROM `users` WHERE login="admin"'));

      if($login=="admin" && $password==$pass[0])
      {
        $data["login_status"] = "access_granted";

        session_start();
        $_SESSION['admin'] = $password;
        header('Location:/');
      }
      else
      {
        $data["login_status"] = "access_denied";
        session_start();
    	session_destroy();
      
      }
    }
    else
    {
      $data["login_status"] = "";

    }
    return $data;
  }
}
