<?php
class Model_Edit extends Model
{
 public function get_data()
 {
   $id = intval($_GET['id']); //проверка от SQL-инъекций
   $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
   if (mysqli_connect_errno()) {
     echo "Ошибка подключения к серверу MySQL. Код ошибки:".mysqli_connect_error();
   }
   else
   {
        $mysqli->set_charset("utf8");
        $data = mysqli_fetch_array($mysqli->query('SELECT * FROM `tasks` WHERE `id` = '.$id));
   }

   return $data;
 }

  public function update_data($id,$task,$status,$admin_edit=0)
  {

    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (mysqli_connect_errno()) {
        echo "Ошибка подключения к серверу MySQL. Код ошибки:".mysqli_connect_error();
    }
    else
      {

        $mysqli->set_charset("utf8");
        $stmt = $mysqli->stmt_init();
        $stmt->prepare("UPDATE `tasks` SET `task`= ?,`status`=?,`admin_edit`=? WHERE `id` = ?");
        $stmt->bind_param('siii', $task , $status , $admin_edit , $id);
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
        header('Location:/');
      }
            return true;
  }
 }
