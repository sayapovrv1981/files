<?php

class Model_Add extends Model
{

  public function insert_data($username,$email,$task)
  {
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (mysqli_connect_errno()) {
        echo "Ошибка подключения к серверу MySQL. Код ошибки:".mysqli_connect_error();
    }
    else
      {
        $mysqli->set_charset("utf8"); 
        $mysqli->query("INSERT INTO `tasks` VALUES (null,'".$username."','".$email."','".$task."',0,0,0)");
       // echo "INSERT INTO `tasks` VALUES (null,'".$username."','".$email."','".$task."',0,0,0)";
       /* 
        $stmt = $mysqli->stmt_init();
        $stmt->prepare("INSERT INTO `tasks` VALUES (null,?,?,?,0,0)");
        $stmt->bind_param('sssii', $username , $email , $task ,$status, $admin_edit);
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
        */
       header('Location:/');             

             
            
            return true;


      }
  }
}
