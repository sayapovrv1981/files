<?php

class Model_Main extends Model
{
  public function get_data()
  {
    //выводим массив задач
    //cсоединение с БД
    //echo DB_HOST, DB_USER, DB_PASS, DB_NAME;
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if (mysqli_connect_errno()) {
        echo "Ошибка подключения к серверу MySQL. Код ошибки:".mysqli_connect_error();
        return([]);
    }

        $row_num = mysqli_fetch_array($mysqli->query('SELECT count(*) FROM `tasks`'));
        $mysqli->set_charset("utf8");

            if (isset($_GET['sort']))
            {
              $order = "ORDER BY ".str_replace("%20"," ",$_GET['sort']);
            }
            else {
              $order = "ORDER BY username ASC";
            }

        // формирование суффикса LIMIT в запросе
        $limit="";
        $current_page = intval($_GET['page']);// запрошенная страница
      //  echo "набор данных",$current_page;
        if(empty($current_page)) $current_page = 1;
        $number = intdiv(lib_tasks_get_total(),ROWS_NUMBER_ONPAGE); // общее количество страниц
        if ((float)(lib_tasks_get_total()/ROWS_NUMBER_ONPAGE) - $number != 0) $number++;
        // Проверяем попадает ли запрашиваемый номер страницы в интервал от 1 до последней)
        if (($current_page > 0)&&($current_page <= $number))
        {
          $first =  ($current_page - 1)*ROWS_NUMBER_ONPAGE; // номер последней записи таблицы с предыдущей страницы
          $limit = " LIMIT $first, ".ROWS_NUMBER_ONPAGE;
        }

        if ($result = $mysqli->query("SELECT * FROM (SELECT id,username,email,task,status,admin_edit FROM `tasks`".$limit.") AS `sorted` ".$order))
          {
            $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
            if (count($result)>0)
            {
            //  echo count($result);
            //  print_r($result);

            	for($i = 0; $i<count($result); $i++)
            	{
                ($result[$i]['status'] == 1) ? $result[$i]['status'] = "Выполнено" : $result[$i][status] ="-";
                ($result[$i]['admin_edit'] == 1) ? $result[$i]['admin_edit'] = "Отредактировано админом" : $result[$i][admin_edit] ="-";

              }
            //      print_r($result);

            }
            return $result;
          }
        }

    public function get_pagination ()

    {
// функция построения пагинации
      if (isset($_GET['sort']))
      {
        $s =str_replace(" ","%20",$_GET['sort']);
      }
      else {
        $s ="username%20ASC";
      }

      $routes = explode('/', $_SERVER['REQUEST_URI']);
  		if ( !empty($routes[1]) )
  		{
  			$controller_name = $routes[1];
  		}
      else {
        $controller_name="index";
      }

      // Строка для возвращаемого результата
      $return_page = "";
      // Через GET-параметр page передаётся номер
      // текущей страницы
      $current_page = intval($_GET['page']);
      if(empty($current_page)) $current_page = 1;
      //echo "#текущей страницы - ", $current_page;
      // Вычисляем число страниц в системе
      $number = intdiv(lib_tasks_get_total(),ROWS_NUMBER_ONPAGE); // общее количество страниц

      if ((float)(lib_tasks_get_total()/ROWS_NUMBER_ONPAGE) - $number != 0) $number++;

      if(($current_page - PAGE_LINK) > 1)
      {
        $return_page .= "<a href=$_SERVER[PHP_SELF]".
              "?page=1&sort=".$s.">
              [1-".ROWS_NUMBER_ONPAGE."]
              </a>&nbsp;&nbsp;...&nbsp;&nbsp;";

        for($i = $current_page - PAGE_LINK; $i<$current_page; $i++)
        {
          $return_page .= "&nbsp;<a href=$_SERVER[PHP_SELF]".
                 "?page=$i&sort=".$s.">
                  [".(($i - 1)*ROWS_NUMBER_ONPAGE + 1).
                  "-".$i*ROWS_NUMBER_ONPAGE."]
                  </a>&nbsp;";
        }
      }
      else
      {

        for($i = 1; $i<$current_page; $i++)
        {
          $return_page .= "&nbsp;<a href=$_SERVER[PHP_SELF]".
                 "?page=$i&sort=".$s.">
                 [".(($i - 1)*ROWS_NUMBER_ONPAGE + 1).
                 "-".$i*ROWS_NUMBER_ONPAGE."]
                  </a>&nbsp;";
        }
      }
      // Проверяем есть ли ссылки справа
      if($current_page + PAGE_LINK < $number)
      {

        for($i = $current_page; $i<=$current_page + PAGE_LINK; $i++)
        {
          if($current_page == $i)
            $return_page .= "&nbsp;[".
                (($i - 1) * ROWS_NUMBER_ONPAGE + 1).
                 "-".$i*ROWS_NUMBER_ONPAGE."]&nbsp;";
          else
            $return_page .= "&nbsp;<a href=$_SERVER[PHP_SELF]".
                 "?page=$i&sort=".$s.">
                 [".(($i - 1)*ROWS_NUMBER_ONPAGE + 1).
                 "-".$i*ROWS_NUMBER_ONPAGE."]
                 </a>&nbsp;";
        }
        $return_page .= "&nbsp;...&nbsp;&nbsp;".
             "<a href=$_SERVER[PHP_SELF]".
             "?page=$number&sort=".$s.">
             [".(($number - 1)*ROWS_NUMBER_ONPAGE + 1).
             "-".lib_tasks_get_total()."]
             </a>&nbsp;";
      }
      else
      {

        for($i = $current_page; $i<=$number; $i++)
        {
          if($number == $i)
          {
            if($current_page == $i)
              $return_page .= "&nbsp;[".
                              (($i - 1)*ROWS_NUMBER_ONPAGE + 1).
                              "-".lib_tasks_get_total()."]&nbsp;";
            else
              $return_page .= "&nbsp;<a href=$_SERVER[PHP_SELF]".
                   "?page=$i&sort=".$s.">
                   [".(($i - 1)*ROWS_NUMBER_ONPAGE + 1).
                   "-".lib_tasks_get_total()."]
                   </a>&nbsp;";
          }
          else
          {
            if($current_page == $i)
              $return_page .= "&nbsp;[".
                  (($i - 1)*ROWS_NUMBER_ONPAGE + 1).
                   "-".$i*ROWS_NUMBER_ONPAGE."]&nbsp;";
            else
              $return_page .= "&nbsp;<a href=$_SERVER[PHP_SELF]".
                   "?page=$i&sort=".$s.">
                   [".(($i - 1)*ROWS_NUMBER_ONPAGE + 1).
                   "-".($i*ROWS_NUMBER_ONPAGE)."]
                   </a>&nbsp;";
          }
        }
      }
      return $return_page;

    }






}
