<?php
/*
 библиотека.
*/
  function lib_tasks_get_total()
  //функция подсета количества записей в таблице tasks
  {
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $row_num = mysqli_fetch_array($mysqli->query('SELECT count(*) FROM `tasks`'));
    return $row_num[0];
  }
  function lib_auth_check_ok ()
  {// проверка корректности пароля admin в session
   $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

   if (mysqli_connect_errno())
  	{
  		echo "Ошибка подключения к серверу MySQL. Код ошибки:".mysqli_connect_error();

  		return false;
  	}
   $pass = mysqli_fetch_array($mysqli->query('SELECT pass FROM `users` WHERE login="admin"'));
   if (count($pass)>0)
   {
      session_start();
      return   ($_SESSION['admin'] == $pass[0]);
   }
   else return false;

  }
