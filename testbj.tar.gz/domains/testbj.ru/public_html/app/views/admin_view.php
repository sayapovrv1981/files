<h1>Перечень задач</h1>
<p>
<table>
<tr>
	<a href="/add">Добавление задачи</a>
</tr>
<tr>
	<td>Пользователь</td>
	<td>E-mail</td>
	<td>Задача</td>
	<td>Статус</td>
	<td>Отредактировано администратором</td>
</tr>
<?php
//var_dump($data);
if (count($data)>0)
{
	foreach($data as $row)
	{
		echo '<tr>
						<td>'.$row['username'].'</td>
						<td>'.$row['email'].'</td>
						<td>'.$row['task'].'</td>
						<td>'.$row['status'].'</td>
						<td>'.$row['admin_edit'].'</td>
					</tr>';
	}
}

?>
</table>
	<p>
		<?php
		echo $pages;
		?>
	</p>
</p>
