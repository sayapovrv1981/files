<h1>Редактирование задачи</h1>
<p>
<form action="/edit/" method="post">
<table class="edit">
	<tr>
		<th colspan="2"></th>
	</tr>
	<tr>
		<td>Имя пользователя</td>
		<td><input type="text" name="username" value="<?=$data['username']?>" readonly></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><input type="email" name="email" value="<?=$data['email']?>" readonly></td>
	</tr>
  <tr>
		<td>Задача</td>
		<td><input type=text name="task" value="<?=$data['task']?>" required></td>
	</tr>
<tr>
		<td>Статус</td>
		<?php
				($data['status']==1) ? $s='checked="checked"' : $s='';
		?>
		<td><input  type=checkbox  value="<?=$data['status']?>" <?=$s?> id="status">
                    <input  type=hidden name="status" value="" <?=$s?> id="pub">
                </td>
	</tr>
 <tr>
	</tr>
	<tr>
		 <td></td>
		 <td><input type=hidden name="id" value="<?=$data['id']?>"></td>
	 </tr>
	<th colspan="2" style="text-align: right">
	<input type="submit" value="Сохранить" name="btn"
	style="width: 150px; height: 30px;"></th>
</table>
</form>
</p>

<script>
$(function(){
 $("#status").change(function()
 {
    $("#pub").val(this.checked ? 1 : 0);
    
  })
});
</script>
