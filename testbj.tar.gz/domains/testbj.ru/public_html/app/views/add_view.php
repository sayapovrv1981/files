<h1>Страница добавления задачи</h1>
<p>
<form action="/add/" method="post">
<table class="login">
	<tr>
		<th colspan="2"></th>
	</tr>
	<tr>
		<td>Имя пользователя</td>
		<td><input type="text" name="username" required></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><input type="email" name="email" required></td>
	</tr>
  <tr>
		<td>Задача</td>
		<td><input type=text name="task" required></td>
	</tr>
	
	<th colspan="2" style="text-align: right">
	<input type="submit" value="Сохранить" name="btn"
	style="width: 150px; height: 30px;"></th>
</table>
</form>
</p>
