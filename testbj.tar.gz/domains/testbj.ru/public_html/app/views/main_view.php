<?php
if (isset($data)) {
      if  ($data["login_status"] == "access_granted") echo "Введенные при авторизации данные некорректны";
}
if (lib_auth_check_ok ()) {?>
	<div>
		<div>
			<p>Предоставлен доступ Администратора</p>
		</div>
		<div>
			<button class="btn btn-warning" type="button"><a href="/logout">Выход</a></button>
		</div>
	</div>
<?}
else {?>
	<div>
		<div>
			<p>Предоставлен доступ Пользователя</p>
		</div>
		<div>
			<button class="btn btn-warning" type="button"><a href="/login">Вход</a></button>
		</div>

	</div>
<?}?>
<h3>Перечень задач</h3>
<p>
		<button class="btn btn-warning" type="button"><a href="/add">Добавление задачи</a></button>
	<?php

						$Uri=$_SERVER['REQUEST_URI'];
						if ((! (isset($Uri)))||($Uri=="/"))
							{
								$Uri = "index";
							}
                                                $g = htmlspecialchars($_GET['sort'],ENT_COMPAT,'utf-8');

						if (isset($g))
						{
							$s = str_replace($g,'username',str_replace("%20"," ",$Uri));

						}
						else
						if (count($_GET)>0)
									{
										$s = $Uri.'&sort=username';

									}
						else
								{
										$s = $Uri.'?sort=username';
								}
		?>
<table class="table">
	<thead>
		<tr>
			<th scope="col">
				<div>
					<p>Пользователь</p>
					<a href="<?=$s.' ASC'?>">возр</a>
					<a href="<?=$s.' DESC'?>">убыв</a>
				</div>
			</th>

	<?php
                                                $g = htmlspecialchars($_GET['sort'],ENT_COMPAT,'utf-8');

						if (isset($g))
						{
							$s = str_replace($g,'email',str_replace("%20"," ",$Uri));

						}
						else
						if (count($_GET)>0)
									{
										$s = $Uri.'&sort=email';

									}
						else
								{
										$s = $Uri.'?sort=email';

								}
				?>
	 <th scope="col">
		<div>
			<p>Email</p>
			<a href="<?=$s.' ASC'?>">возр</a>
			<a href="<?=$s.' DESC'?>">убыв</a>
		</div>
	</th>
	<?php
                                                $g = htmlspecialchars($_GET['sort'],ENT_COMPAT,'utf-8');

						if (isset($g))
						{
							$s = str_replace($g,'task',str_replace("%20"," ",$Uri));
						}
						else
						if (count($_GET)>0)
									{
										$s = $Uri.'&sort=task';
									}
						else
								{
										$s = $Uri.'?sort=task';
								}
		?>
	 <th scope="col">
		<div>
			<p>Задача</p>
			<a href="<?=$s.' ASC'?>">возр</a>
			<a href="<?=$s.' DESC'?>">убыв</a>
		</div>
	</th>
	<?php
                                                $g = htmlspecialchars($_GET['sort'],ENT_COMPAT,'utf-8');

						if (isset($g))
						{
							$s = str_replace($g,'status',str_replace("%20"," ",$_SERVER['REQUEST_URI']));
						}
						else
						if (count($_GET)>0)
									{
										$s = $_SERVER['REQUEST_URI'].'&sort=status';
									}
						else
								{
										$s = $_SERVER['REQUEST_URI'].'?sort=status';
								}
		?>
	 <th scope="col">
		<p>Статус</p>
		<a href="<?=$s.' ASC'?>">возр</a>
		<a href="<?=$s.' DESC'?>">убыв</a>
	</th>
</thead>
<tbody>
<?php

if (count($data)>0)
{
	foreach($data as $row)
	{
		echo '<tr>
						<td>'.$row['username'].'</td>
						<td>'.$row['email'].'</td>
						<td>'.$row['task'].'</td>
						<td>'.$row['status'].'</td>
					</tr>';
	}
}

?>
</tbody>
</table>
	<p>
		<?php
		echo $pages;
		?>
	</p>
</p>
