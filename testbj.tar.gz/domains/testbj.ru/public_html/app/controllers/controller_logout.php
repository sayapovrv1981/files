<?php

class Controller_Logout extends Controller
{
	function __construct()
	{

	}

	function action_index()
	{
		session_start();
		session_destroy();
		header('Location:/');
	}

}
