<?php
class Controller_Edit extends Controller
{
	function __construct()
	{
		$this->model = new Model_Edit();
		$this->view = new View();
	}
function action_index()
{
  if (isset($_POST['id']) && isset($_POST['task']) && isset($_POST['status'])&&lib_auth_check_ok ())
  {

                $id=htmlspecialchars($_POST['id'],ENT_QUOTES,'utf-8');
		$task = htmlspecialchars($_POST['task'],ENT_QUOTES,'utf-8');
		$status = htmlspecialchars($_POST['status'],ENT_QUOTES,'utf-8');
                $admin_edit=0;
		$data = $this->model->get_data();


                if (($admin_edit==0)&&(strcmp($data['task'],$task)<>0)) $admin_edit=1;

                 
                  
          
   	        $this->model->update_data($id,$task,$status,$admin_edit);
  }
		$data = $this->model->get_data();

    $this->view->generate('edit_view.php', 'template_view.php', $data);
}
}
