<?php
class Controller_Main extends Controller
{
	function __construct()
	{
		$this->model = new Model_Main();
		$this->view = new View();
	}

	function action_index()
	{
		$data = $this->model->get_data();
		$pages = $this->model->get_pagination();
		//$adress = $this->model->get_adress();
		if (lib_auth_check_ok ()) $this->view->generate('main_adminview.php', 'template_view.php', $data, $pages);

		else	$this->view->generate('main_view.php', 'template_view.php', $data, $pages);
	}
}
