<?php
class Controller_Add extends Controller
{
	function __construct()
	{
		$this->model = new Model_Add();
		$this->view = new View();
	}

function action_index()
{
  if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['task']))
  {

    $username = htmlspecialchars($_POST['username'],ENT_QUOTES,'utf-8');
    $email =htmlspecialchars($_POST['email'],ENT_QUOTES,'utf-8');
    $task =htmlspecialchars($_POST['task'],ENT_QUOTES,'utf-8');
    $status =htmlspecialchars($_POST['status'],ENT_QUOTES,'utf-8');
    $this->model->insert_data($username,$email,$task,$status);

  }
    $this->view->generate('add_view.php', 'template_view.php');
}
}
